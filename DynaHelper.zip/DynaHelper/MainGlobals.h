#ifndef  MAIN_GLOBALS_H
#define  MAIN_GLOBALS_H
#include <Windows.h>


extern HINSTANCE _globHINST;


#endif